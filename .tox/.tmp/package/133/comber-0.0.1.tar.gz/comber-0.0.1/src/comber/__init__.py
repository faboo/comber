"""
Comber

"""
from math import inf
from .parser import ParseError
from .combinator import C, Id, Lit, Seq, Choice, Repeat
